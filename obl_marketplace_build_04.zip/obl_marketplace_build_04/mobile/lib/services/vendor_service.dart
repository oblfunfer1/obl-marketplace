import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_session.dart';

class VendorService {
  static const baseUrl=String.fromEnvironment('API_URL',defaultValue:'http://10.0.2.2:3000/api/v1');

  Future<Map<String,dynamic>> registerVendor(Map<String,dynamic> payload) async {
    final token=await AuthSession.token();
    final r=await http.post(Uri.parse('$baseUrl/vendors/register'),headers:{'Content-Type':'application/json','Authorization':'Bearer $token'},body:jsonEncode(payload));
    final data=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(data['message']??'Vendor registration failed');
    return data;
  }

  Future<Map<String,dynamic>> createProduct(Map<String,dynamic> payload) async {
    final token=await AuthSession.token();
    final r=await http.post(Uri.parse('$baseUrl/products'),headers:{'Content-Type':'application/json','Authorization':'Bearer $token'},body:jsonEncode(payload));
    final data=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(data['message']??'Product creation failed');
    return data;
  }
}
