import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_session.dart';

class AdminService {
  static const baseUrl=String.fromEnvironment('API_URL',defaultValue:'http://10.0.2.2:3000/api/v1');

  Future<Map<String,dynamic>> dashboard() async {
    final token=await AuthSession.token();
    final r=await http.get(Uri.parse('$baseUrl/admin/dashboard'),headers:{'Authorization':'Bearer $token'});
    final data=jsonDecode(r.body);
    if(r.statusCode>=400) throw Exception(data['message']??'Admin request failed');
    return data;
  }

  Future<List<dynamic>> pendingVendors() async {
    final token=await AuthSession.token();
    final r=await http.get(Uri.parse('$baseUrl/admin/vendors/pending'),headers:{'Authorization':'Bearer $token'});
    if(r.statusCode>=400) throw Exception('Unable to load vendors');
    return jsonDecode(r.body);
  }

  Future<void> decideVendor(String id,bool approve) async {
    final token=await AuthSession.token();
    final r=await http.patch(Uri.parse('$baseUrl/admin/vendors/$id/${approve?'approve':'reject'}'),headers:{'Authorization':'Bearer $token'});
    if(r.statusCode>=400) throw Exception('Unable to update vendor');
  }

  Future<List<dynamic>> pendingProducts() async {
    final token=await AuthSession.token();
    final r=await http.get(Uri.parse('$baseUrl/admin/products/pending'),headers:{'Authorization':'Bearer $token'});
    if(r.statusCode>=400) throw Exception('Unable to load products');
    return jsonDecode(r.body);
  }

  Future<void> decideProduct(String id,bool approve) async {
    final token=await AuthSession.token();
    final r=await http.patch(Uri.parse('$baseUrl/admin/products/$id/${approve?'approve':'reject'}'),headers:{'Authorization':'Bearer $token'});
    if(r.statusCode>=400) throw Exception('Unable to update product');
  }
}
