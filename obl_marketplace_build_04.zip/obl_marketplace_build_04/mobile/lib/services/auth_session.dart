import 'package:shared_preferences/shared_preferences.dart';

class AuthSession {
  static const tokenKey='obl_access_token';
  static const roleKey='obl_role';

  static Future<void> save(String token,String role) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(tokenKey,token);
    await p.setString(roleKey,role);
  }
  static Future<String?> token() async => (await SharedPreferences.getInstance()).getString(tokenKey);
  static Future<String?> role() async => (await SharedPreferences.getInstance()).getString(roleKey);
  static Future<void> clear() async {
    final p=await SharedPreferences.getInstance();
    await p.remove(tokenKey); await p.remove(roleKey);
  }
}
