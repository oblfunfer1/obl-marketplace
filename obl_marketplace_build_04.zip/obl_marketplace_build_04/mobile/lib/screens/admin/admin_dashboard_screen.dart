import 'package:flutter/material.dart';
import '../../services/admin_service.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});
  @override State<AdminDashboardScreen> createState()=>_AdminDashboardScreenState();
}
class _AdminDashboardScreenState extends State<AdminDashboardScreen>{
  final api=AdminService(); Map<String,dynamic>? stats; List<dynamic> vendors=[]; List<dynamic> products=[];
  bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    try{
      final s=await api.dashboard(); final v=await api.pendingVendors(); final p=await api.pendingProducts();
      if(mounted)setState(()=>{stats=s,vendors=v,products=p,loading=false});
    }catch(e){if(mounted){setState(()=>loading=false);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}}
  }
  Future<void> vendor(String id,bool ok) async {await api.decideVendor(id,ok);await load();}
  Future<void> product(String id,bool ok) async {await api.decideProduct(id,ok);await load();}

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('OBL Admin',style:TextStyle(fontWeight:FontWeight.w900))),
    body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(
      onRefresh:load,child:ListView(padding:const EdgeInsets.all(18),children:[
        const Text('Marketplace control center',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),
        const SizedBox(height:16),
        Wrap(spacing:10,runSpacing:10,children:[
          _stat('Pending vendors','${stats?['vendorsPending']??0}'),
          _stat('Pending products','${stats?['productsPending']??0}'),
          _stat('Customers/users','${stats?['users']??0}'),
          _stat('Live products','${stats?['activeProducts']??0}')
        ]),
        const SizedBox(height:24),
        const Text('Vendor approvals',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
        ...vendors.map((v)=>Card(child:ListTile(
          title:Text(v['businessName']??'Vendor'),subtitle:Text(v['store']?['name']??'Store'),
          trailing:Wrap(children:[
            IconButton(onPressed:()=>vendor(v['id'],false),icon:const Icon(Icons.close)),
            IconButton(onPressed:()=>vendor(v['id'],true),icon:const Icon(Icons.check))
          ]),
        ))),
        const SizedBox(height:18),
        const Text('Product approvals',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
        ...products.map((p)=>Card(child:ListTile(
          title:Text(p['name']??'Product'),subtitle:Text('₦${p['price']}'),
          trailing:Wrap(children:[
            IconButton(onPressed:()=>product(p['id'],false),icon:const Icon(Icons.close)),
            IconButton(onPressed:()=>product(p['id'],true),icon:const Icon(Icons.check))
          ]),
        ))),
      ]),
    ),
  );

  Widget _stat(String label,String value)=>SizedBox(width:160,child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(value,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900)),Text(label)
  ]))));
}
