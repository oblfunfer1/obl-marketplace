# OBL MARKETPLACE — Build 0.4

Admin + security milestone:
- JWT authentication guard
- Role guards
- Authenticated vendor registration
- Authenticated vendor product creation/edit/delete
- Admin vendor approval/rejection
- Admin product approval/rejection
- Admin dashboard starter
- Vendor dashboard starter
- Product image URL management foundation
- Cart database foundation

This is a development build. Real cloud image storage, Paystack checkout, order splitting,
vendor payouts, notifications and production deployment are the next milestones.
