# Build 0.4 — Admin + Security

## Added
- JWT bearer authentication
- Role guard foundation
- Admin dashboard API
- Vendor approval/rejection
- Product approval/rejection
- Authenticated vendor registration
- Authenticated vendor product creation/edit/delete
- Cart database + API foundation
- Flutter admin dashboard
- Persistent mobile auth token storage

## Run
Backend:
```bash
npm install
npx prisma generate
npx prisma migrate dev --name admin_security_cart
npm run start:dev
```

Flutter:
```bash
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000/api/v1
```

## Important
The admin role must be assigned in the database before using admin endpoints.
The next production pass should add stricter DTO validation, audit logging, refresh tokens,
rate limiting and server-side ownership checks with proper HTTP errors.

## Next milestone — Build 0.5
- Real product image uploads to cloud storage
- Customer cart UI
- Product detail UI
- Wishlist
- Address book
- Checkout
- Paystack payment initialization/webhook verification
- Multi-vendor order splitting
