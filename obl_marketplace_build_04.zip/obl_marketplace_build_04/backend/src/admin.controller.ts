import { Body, Controller, Get, Param, Patch, UseGuards } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { JwtAuthGuard } from './security/jwt-auth.guard';
import { Roles } from './security/roles.decorator';

@Controller('api/v1/admin')
@UseGuards(JwtAuthGuard)
@Roles('ADMIN','SUPER_ADMIN')
export class AdminController {
  constructor(private readonly prisma: PrismaService) {}

  @Get('dashboard')
  async dashboard() {
    const [vendorsPending,productsPending,users,products] = await Promise.all([
      this.prisma.vendor.count({where:{approvalStatus:'PENDING'}}),
      this.prisma.product.count({where:{status:'PENDING_APPROVAL'}}),
      this.prisma.user.count(),
      this.prisma.product.count({where:{status:'ACTIVE'}})
    ]);
    return {vendorsPending,productsPending,users,activeProducts:products};
  }

  @Get('vendors/pending')
  pendingVendors() {
    return this.prisma.vendor.findMany({where:{approvalStatus:'PENDING'},include:{store:true,user:true}});
  }

  @Patch('vendors/:id/:decision')
  decideVendor(@Param('id') id:string,@Param('decision') decision:string) {
    const approvalStatus = decision === 'approve' ? 'APPROVED' : 'REJECTED';
    return this.prisma.vendor.update({where:{id},data:{approvalStatus:approvalStatus as any}});
  }

  @Get('products/pending')
  pendingProducts() {
    return this.prisma.product.findMany({where:{status:'PENDING_APPROVAL'},include:{vendor:{include:{store:true}},category:true,images:true}});
  }

  @Patch('products/:id/:decision')
  decideProduct(@Param('id') id:string,@Param('decision') decision:string) {
    const status = decision === 'approve' ? 'ACTIVE' : 'SUSPENDED';
    return this.prisma.product.update({where:{id},data:{status:status as any}});
  }
}
