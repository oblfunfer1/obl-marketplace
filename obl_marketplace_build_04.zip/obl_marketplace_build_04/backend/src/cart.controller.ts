import { Body, Controller, Delete, Get, Param, Post, Put, Req, UseGuards } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { JwtAuthGuard } from './security/jwt-auth.guard';

@Controller('api/v1/cart')
@UseGuards(JwtAuthGuard)
export class CartController {
  constructor(private readonly prisma: PrismaService) {}

  private async getCart(userId:string) {
    return this.prisma.cart.upsert({
      where:{userId},
      create:{userId},
      update:{},
      include:{items:{include:{product:{include:{images:true,vendor:{include:{store:true}}}}}}}
    });
  }

  @Get()
  get(@Req() req:any) { return this.getCart(req.user.sub); }

  @Post('items')
  async add(@Req() req:any,@Body() body:{productId:string;quantity:number}) {
    const product = await this.prisma.product.findUnique({where:{id:body.productId}});
    if (!product || product.status !== 'ACTIVE') throw new Error('Product unavailable');
    const cart = await this.prisma.cart.upsert({where:{userId:req.user.sub},create:{userId:req.user.sub},update:{}});
    return this.prisma.cartItem.upsert({
      where:{cartId_productId:{cartId:cart.id,productId:product.id}},
      create:{cartId:cart.id,productId:product.id,quantity:body.quantity,unitPrice:product.discountPrice ?? product.price},
      update:{quantity:{increment:body.quantity},unitPrice:product.discountPrice ?? product.price},
      include:{product:true}
    });
  }

  @Put('items/:id')
  update(@Req() req:any,@Param('id') id:string,@Body() body:{quantity:number}) {
    return this.prisma.cartItem.update({where:{id},data:{quantity:body.quantity}});
  }

  @Delete('items/:id')
  remove(@Param('id') id:string) { return this.prisma.cartItem.delete({where:{id}}); }
}
