import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const auth = request.headers.authorization;
    if (!auth?.startsWith('Bearer ')) throw new UnauthorizedException('Authentication required');
    try {
      request.user = jwt.verify(auth.slice(7), process.env.JWT_SECRET || 'dev-only-secret');
      return true;
    } catch {
      throw new UnauthorizedException('Invalid or expired token');
    }
  }
}
