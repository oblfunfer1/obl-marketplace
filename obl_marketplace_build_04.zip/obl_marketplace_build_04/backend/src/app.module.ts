import { Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { AuthController } from './auth.controller';
import { AdminController } from './admin.controller';
import { VendorsController } from './vendors.controller';
import { ProductsController } from './products.controller';
import { CartController } from './cart.controller';
import { JwtAuthGuard } from './security/jwt-auth.guard';
import { RolesGuard } from './security/roles.guard';

@Module({
  controllers: [AuthController, AdminController, VendorsController, ProductsController, CartController],
  providers: [PrismaService, JwtAuthGuard, RolesGuard],
})
export class AppModule {}
