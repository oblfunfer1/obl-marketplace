import { Body, Controller, Delete, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { JwtAuthGuard } from './security/jwt-auth.guard';

@Controller('api/v1/products')
export class ProductsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  list(@Query('q') q?:string,@Query('category') category?:string,@Query('vendorId') vendorId?:string) {
    return this.prisma.product.findMany({
      where:{status:'ACTIVE',vendor:{approvalStatus:'APPROVED'},...(q?{name:{contains:q,mode:'insensitive'}}:{}),...(category?{category:{slug:category}}:{}),...(vendorId?{vendorId}: {})},
      include:{images:true,category:true,vendor:{include:{store:true}}},
      orderBy:{createdAt:'desc'}
    });
  }

  @Get(':id')
  get(@Param('id') id:string) {
    return this.prisma.product.findUnique({where:{id},include:{images:true,category:true,vendor:{include:{store:true}}}});
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  async create(@Req() req:any,@Body() body:{categoryId:string;name:string;slug:string;description:string;price:number;discountPrice?:number;stockQuantity:number;sku?:string;imageUrls?:string[]}) {
    const vendor = await this.prisma.vendor.findUnique({where:{userId:req.user.sub}});
    if (!vendor) throw new Error('Vendor account not found');
    return this.prisma.product.create({
      data:{vendorId:vendor.id,categoryId:body.categoryId,name:body.name,slug:body.slug,description:body.description,price:body.price,discountPrice:body.discountPrice,stockQuantity:body.stockQuantity,sku:body.sku,status:'PENDING_APPROVAL',
        images:body.imageUrls?{create:body.imageUrls.map((imageUrl,i)=>({imageUrl,sortOrder:i}))}:undefined},
      include:{images:true}
    });
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  async update(@Req() req:any,@Param('id') id:string,@Body() body:any) {
    const vendor = await this.prisma.vendor.findUnique({where:{userId:req.user.sub}});
    const product = await this.prisma.product.findUnique({where:{id}});
    if (!vendor || !product || product.vendorId !== vendor.id) throw new Error('Product not found');
    return this.prisma.product.update({where:{id},data:{...body,status:'PENDING_APPROVAL'}});
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  async remove(@Req() req:any,@Param('id') id:string) {
    const vendor = await this.prisma.vendor.findUnique({where:{userId:req.user.sub}});
    const product = await this.prisma.product.findUnique({where:{id}});
    if (!vendor || !product || product.vendorId !== vendor.id) throw new Error('Product not found');
    return this.prisma.product.update({where:{id},data:{status:'DELETED'}});
  }
}
