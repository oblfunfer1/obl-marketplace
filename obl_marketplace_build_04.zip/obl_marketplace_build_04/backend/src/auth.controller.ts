import { Body, Controller, Post, ConflictException, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';

@Controller('api/v1/auth')
export class AuthController {
  constructor(private readonly prisma: PrismaService) {}

  @Post('register')
  async register(@Body() dto: {firstName:string;lastName:string;email:string;password:string;phone?:string}) {
    const email = dto.email.toLowerCase();
    if (await this.prisma.user.findUnique({where:{email}})) throw new ConflictException('Email is already registered');
    const passwordHash = await bcrypt.hash(dto.password, 12);
    const user = await this.prisma.user.create({
      data: { firstName:dto.firstName,lastName:dto.lastName,email,passwordHash,phone:dto.phone,customerProfile:{create:{}} },
      select:{id:true,firstName:true,lastName:true,email:true,role:true}
    });
    return {user, accessToken: jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET||'dev-only-secret')};
  }

  @Post('login')
  async login(@Body() dto:{email:string;password:string}) {
    const user = await this.prisma.user.findUnique({where:{email:dto.email.toLowerCase()}});
    if (!user || !(await bcrypt.compare(dto.password,user.passwordHash))) throw new UnauthorizedException('Invalid email or password');
    return {
      user:{id:user.id,firstName:user.firstName,lastName:user.lastName,email:user.email,role:user.role},
      accessToken:jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET||'dev-only-secret')
    };
  }
}
