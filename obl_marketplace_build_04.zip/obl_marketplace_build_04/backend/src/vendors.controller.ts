import { Body, Controller, Get, Param, Post, UseGuards, Req } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { JwtAuthGuard } from './security/jwt-auth.guard';

@Controller('api/v1/vendors')
export class VendorsController {
  constructor(private readonly prisma: PrismaService) {}

  @Get()
  listApproved() {
    return this.prisma.vendor.findMany({where:{approvalStatus:'APPROVED'},include:{store:true},orderBy:{createdAt:'desc'}});
  }

  @Get(':id')
  get(@Param('id') id:string) {
    return this.prisma.vendor.findUnique({where:{id},include:{store:true,products:{include:{images:true,category:true}}}});
  }

  @Post('register')
  @UseGuards(JwtAuthGuard)
  async register(@Req() req:any,@Body() body:{businessName:string;businessEmail:string;businessPhone:string;businessAddress?:string;storeName:string;storeSlug:string;description?:string}) {
    const userId = req.user.sub;
    const existing = await this.prisma.vendor.findUnique({where:{userId}});
    if (existing) return existing;
    return this.prisma.vendor.create({
      data:{
        userId,businessName:body.businessName,businessEmail:body.businessEmail,businessPhone:body.businessPhone,businessAddress:body.businessAddress,
        store:{create:{name:body.storeName,slug:body.storeSlug,description:body.description}}
      },include:{store:true}
    });
  }
}
